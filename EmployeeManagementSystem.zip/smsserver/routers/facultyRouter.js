const express = require("express");
const Faculty = require("../models/Faculty");
const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const faculty = new Faculty(req.body);
    await faculty.save();
    res.status(201).send(faculty);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const faculties = await Faculty.find();
    res.status(200).send(faculties);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
});

const getFacultyById = async (req, res, next) => {
  try {
    const faculty = await Faculty.findOne({ id: req.params.id });
    if (faculty === null) {
      return res.status(400).send({ message: "Faculty not found" });
    }
    res.faculty = faculty;
  } catch (error) {
    return res.status(500).send({ message: error.message });
  }
  next();
};

router.get("/:id", getFacultyById, async (req, res) => {
  res.status(200).send(res.faculty);
});

router.delete("/:id", getFacultyById, async (req, res) => {
  try {
    await Faculty.deleteOne({ id: req.params.id });
    res
      .status(200)
      .send({ success: true, message: "Faculty deleted succesfully" });
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
});

router.patch("/:id", getFacultyById, async (req, res) => {
  try {
    const faculty = res.faculty;
    faculty.designation = req.body.designation;
    faculty.qualification = req.body.qualification;
    faculty.email = req.body.email;

    const newFaculty = await faculty.save();
    res.status(200).send(newFaculty);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
});

module.exports = router;
