const express = require("express");
const router = express.Router();
const Course = require("../models/Course");
const csvToJson = require("csvtojson");
const multer = require("multer");

router.post("/", async (req, res) => {
  try {
    const course = new Course(req.body);
    await course.save();
    res.status(200).send(course);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const courses = await Course.find();
    res.status(200).send(courses);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

const getCourse = async (req, res, next) => {
  let course;
  try {
    course = await Course.findById(req.params.id);
    if (course === null) {
      return res.status(404).json({ message: "Not found" });
    }
    res.course = course;
    next();
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

router.get("/:id", getCourse, async (req, res) => {
  res.json(res.course);
});

router.put("/:id", getCourse, async (req, res) => {
  if (req.body.code !== null) {
    res.course.code = req.body.code;
  }
  if (req.body.name !== null) {
    res.course.name = req.body.name;
  }
  if (req.body.year !== null) {
    res.course.year = req.body.year;
  }
  try {
    const updatedCourse = await res.course.save();
    res.status(200).send(updatedCourse);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.delete("/:id", getCourse, async (req, res) => {
  try {
    await res.course.deleteOne();
    res
      .status(200)
      .send({ success: true, message: "Course deleted successfully" });
  } catch (error) {
    res.status(400).send({ success: false, message: error.message });
  }
});

const storage = multer.memoryStorage();
const upload = multer({
  storage: storage.storage,
});

router.post("/upload", upload.single("file"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json("File not found");
  }
  try {
    const data = await csvToJson().fromString(req.file.buffer.toString());
    await Course.insertMany(data);
    res.status(200).json({ message: "Courses saved successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
