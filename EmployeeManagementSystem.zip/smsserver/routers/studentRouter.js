const express = require("express");
const router = express.Router();

const Student = require("../models/Student");

const getStudentById = async (req, res, next) => {
  try {
    const student = Student.findById(req.params.id);
    if (student === null) {
      return res
        .status(404)
        .send({ message: "Cannot find student with that ID" });
    }
    res.student = student;
    next();
  } catch (error) {
    return res.status(500).send({ message: error.message });
  }
};

router.get("/", async (req, res) => {
  try {
    const students = await Student.find();
    res.status(200).send(students);
  } catch (error) {
    return res.status(500).send({ message: error.message });
  }
});

router.post("/", async (req, res) => {
  try {
    const student = new Student(req.body);
    await student.save();
    res.status(200).send(student);
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
});

router.get("/:id", getStudentById, async (req, res) => {
  res.status(200).send(res.student);
});

router.put("/:id", getStudentById, async (req, res) => {
  try {
    const student = { ...res.student, ...req.body };
    await student.save();
    res.status(200).send(student);
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
});

router.delete("/:id", getStudentById, async (req, res) => {
  try {
    await res.student.deleteOne();
    res.status(200).send({ message: "Student deleted successfully" });
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
});

module.exports = router;
