const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");
const courseRouter = require("./routers/courseRouter");
const facultyRouter = require("./routers/facultyRouter");
const studentRouter = require("./routers/studentRouter");

const app = express();
app.use(bodyParser.json());
app.use(cors());

const MONGO_URI =
  "mongodb+srv://admin:admin1234@cluster0.qjsxmq3.mongodb.net/?retryWrites=true&w=majority";

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB Connection error"));

app.use("/api/course", courseRouter);
app.use("/api/faculty", facultyRouter);
app.use("/api/student", studentRouter);

const PORT = 3001;

app.get("/", (req, res) => {
  res.send("First Program!");
});

app.listen(3001, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
