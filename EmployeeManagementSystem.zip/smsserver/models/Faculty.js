const mongoose = require("mongoose");

const FacultySchema = new mongoose.Schema({
  id: Number,
  name: String,
  department: String,
  qualification: String,
  designation: String,
  email: String,
  password: String,
});

const Faculty = mongoose.model("Faculty", FacultySchema);
module.exports = Faculty;
