const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema({
  code: {
    type: String,
    require: true,
  },
  name: {
    type: String,
    require: true,
  },
  year: {
    type: Number,
    require: true,
  },
});

const Course = mongoose.model("Course", courseSchema);

module.exports = Course;
