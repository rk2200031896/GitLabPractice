import { Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./components/Home";
import Faculty from "./components/Faculty";
import Courses from "./components/Courses";
import AddFaculty from "./components/AddFaculty";
import ViewFaculty from "./components/ViewFaculty";
import UpdateFaculty from "./components/UpdateFaculty";
import DeleteFaculty from "./components/DeleteFaculty";
import UpdateFacultyList from "./components/UpdateFacultyList";
import Profile from "./components/Profile";
import NavigationBar from "./components/NavigationBar";

function App() {
  return (
    <div>
      <NavigationBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="courses/" element={<Courses />} />
        <Route path="faculty" element={<Faculty />}>
          <Route path="addFaculty" element={<AddFaculty />} />
          <Route path="viewFaculty" element={<ViewFaculty />} />
          <Route path="updateFaculty" element={<UpdateFacultyList />} />
          <Route path="updateFaculty/:id" element={<UpdateFaculty />} />
          <Route path="deleteFaculty" element={<DeleteFaculty />} />
        </Route>
        <Route path="profile" element={<Profile />} />
        <Route path="student" element={<Profile />} />
      </Routes>
    </div>
  );
}

export default App;
