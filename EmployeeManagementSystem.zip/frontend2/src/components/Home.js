import React from "react";
import { Typography } from "@mui/material";

const Home = () => {
  return (
    <div>
      <Typography variant="h5" style={{ textAlign: "center" }}>
        Student Management System
      </Typography>
    </div>
  );
};

export default Home;
