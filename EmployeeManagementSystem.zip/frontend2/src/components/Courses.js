import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Alert,
  Button,
  Card,
  CardContent,
  Divider,
  FormLabel,
  Grid,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import ModeEditIcon from "@mui/icons-material/ModeEdit";

const Courses = () => {
  const [file, setFile] = useState(null);
  const [fileUploadStatus, setFileUploadStatus] = useState(false);
  const [courseSaveStatus, setCourseSaveStatus] = useState(false);
  const [courses, setCourses] = useState([]);

  const [enteredCourseCode, setEnteredCourseCode] = useState("");
  const [enteredCourseName, setEnteredCourseName] = useState("");
  const [enteredYear, setEnteredYear] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:3001/api/course");
      setCourses(response.data);
    } catch (error) {
      console.log(error.message);
    }
  };

  const handleCourseCodeChange = (event) => {
    setEnteredCourseCode(event.target.value);
  };

  const handleCourseNameChange = (event) => {
    setEnteredCourseName(event.target.value);
  };

  const handleYearChange = (event) => {
    setEnteredYear(event.target.value);
  };

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleAddCourseSubmit = async (event) => {
    event.preventDefault();
    const data = {
      name: enteredCourseName,
      code: enteredCourseCode,
      year: +enteredYear,
    };
    console.log(data);
    try {
      const response = await axios.post(
        "http://localhost:3001/api/course/",
        data,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (response.status === 200) {
        setCourseSaveStatus(true);
        fetchData();
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  const fileUploadHandler = async (event) => {
    if (!file) {
      return;
    }
    console.log("helo");
    const formData = new FormData();
    formData.append("file", file);
    try {
      await axios.post("http://localhost:3001/api/course/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setFileUploadStatus(true);
      fetchData();
    } catch (error) {
      console.error("Error uploading data", error.message);
    }
  };

  const handleDeleteCourse = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/api/course/${id}`);
      fetchData();
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <Stack
      direction="row"
      style={{ marginLeft: 35, marginTop: 15 }}
      spacing={1}
    >
      <Paper elevation={6} sx={{ width: "30%", backgroundColor: "#071952" }}>
        <Stack direction={"column"}>
          <h4 style={{ color: "#35A29F" }}>Course Bulk Upload</h4>
          <Paper sx={{ backgroundColor: "#088395", m: 10 }}>
            <FormLabel>File Upload (.csv)</FormLabel>
            <TextField type="file" onChange={handleFileChange} />
            <br />
            <Button
              variant="contained"
              style={{ color: "white", marginTop: 10 }}
              onClick={fileUploadHandler}
            >
              Upload
            </Button>
            {fileUploadStatus && (
              <Alert severity="success">CSV File Upload Successfully</Alert>
            )}
          </Paper>
          <Divider sx={{ backgroundColor: "#AED2FF" }} />
          <Paper sx={{ backgroundColor: "#AED2FF", m: 3 }}>
            <Card direction="column">
              <Stack direction="column" spacing={2} sx={{ m: 3 }}>
                <Typography variant="h5">Add Course</Typography>
                <Divider />
                <TextField
                  value={enteredCourseCode}
                  onChange={handleCourseCodeChange}
                  label="Course Code"
                  sx={{ m: 3 }}
                />
                <TextField
                  value={enteredCourseName}
                  onChange={handleCourseNameChange}
                  label="Course Name"
                  sx={{ m: 3 }}
                />
                <TextField
                  value={enteredYear}
                  onChange={handleYearChange}
                  label="Year"
                  sx={{ m: 3 }}
                />
                <Button
                  onClick={handleAddCourseSubmit}
                  sx={{ m: 3 }}
                  color="success"
                  variant="contained"
                >
                  Save
                </Button>
                {courseSaveStatus && (
                  <Alert severity="success">Saved Course Successfully</Alert>
                )}
              </Stack>
            </Card>
          </Paper>
        </Stack>
      </Paper>
      <Paper
        elevation={6}
        style={{ marginRight: 15 }}
        sx={{ width: "70%", backgroundColor: "#35A29F" }}
      >
        <h1 align="center">Courses</h1>
        <Grid container spacing={1} sx={{ m: 1 }}>
          {courses.map((course, index) => {
            return (
              <Grid item xs={2} sm={3} md={4} key={index}>
                <Card>
                  <CardContent>
                    <Typography variant="h5" component="h5">
                      Course Code: {course.code}
                    </Typography>
                    <Typography variant="h5" component="h5">
                      Course Name: {course.name}
                    </Typography>
                    <Typography variant="h5" component="h5">
                      Year: {course.year}
                    </Typography>
                    <Button
                      sx={{ marginTop: 3 }}
                      variant="contained"
                      color="info"
                      startIcon={<ModeEditIcon />}
                    >
                      Update
                    </Button>
                    <Button
                      sx={{ marginTop: 3, marginLeft: 5 }}
                      variant="contained"
                      color="error"
                      startIcon={<DeleteIcon />}
                      onClick={() => handleDeleteCourse(course._id)}
                    >
                      Delete
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Paper>
    </Stack>
  );
};

export default Courses;
