import React from "react";
import { NavLink } from "react-router-dom";

const Navbar = () => {
  const linkStyles = ({ isActive }) => {
    return {
      textDecoration: isActive ? "none" : "underline",
      fontWeight: isActive ? "bold" : "normal",
    };
  };
  return (
    <div>
      <nav className="primary-nav">
        <NavLink to="/" style={linkStyles}>
          Home
        </NavLink>
        <NavLink to="/courses" style={linkStyles}>
          Courses
        </NavLink>
        <NavLink to="/faculty" style={linkStyles}>
          Faculty
        </NavLink>
        <NavLink to="/student" style={linkStyles}>
          Student
        </NavLink>
        <NavLink to="/profile" style={linkStyles}>
          Profile
        </NavLink>
      </nav>
    </div>
  );
};

export default Navbar;
