// import React, { useEffect, useState } from "react";
// import {
//   Alert,
//   Button,
//   Card,
//   Divider,
//   FormLabel,
//   Paper,
//   Stack,
//   TextField,
// } from "@mui/material";
// import axios from "axios";

// const Profile = () => {
//   const [file, setFile] = useState(null);
//   const [uploadStatus, setUploadStatus] = useState(false);
//   const [submissionStatus, setSubmissionStatus] = useState(false);

//   const [name, setName] = useState("");
//   const [subject, setSubject] = useState("");
//   const [age, setAge] = useState("");

//   const [studentsList, setStudentsList] = useState([]);

//   useEffect(() => {
//     const fetchStudents = async () => {
//       try {
//         const response = await axios.get("http://localhost:3001/api/student");
//         setStudentsList(response.data);
//       } catch (error) {
//         console.log("Error: ", error.message);
//       }
//     };
//   }, []);

//   const handleNameChange = (event) => {
//     setName(event.target.value);
//   };

//   const handleSubjectChange = (event) => {
//     setSubject(event.target.value);
//   };

//   const handleAgeChange = (event) => {
//     setAge(event.target.value);
//   };

//   const handleFileChange = (event) => {
//     setFile(event.target.value);
//   };

//   const handleUpload = async (event) => {
//     event.preventDefault();
//     if (!file) return;
//     const formData = new FormData();
//     formData.append("file", file);
//     try {
//       await axios.post("http://localhost:3001/api/student/upload", formData, {
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       });
//       setUploadStatus(true);
//     } catch (error) {
//       console.log("Error: ", error.message);
//     }
//   };

//   const handleSubmission = async (event) => {
//     event.preventDefault();
//     try {
//       await axios.post(
//         "http://localhost:3001/api/student",
//         {
//           name: name,
//           subject: subject,
//           age: age,
//         },
//         {
//           headers: {
//             "Content-Type": "application/json",
//           },
//         }
//       );
//       setSubmissionStatus(true);
//     } catch (error) {
//       console.log("Error: ", error.message);
//     }
//   };

//   return (
//     <div>
//       <Stack>
//         <Paper>
//           <Stack>
//             <h2 align="center">Student Profile</h2>
//             <Paper>
//               <FormLabel>File Upload in CSV Format only</FormLabel>
//               <TextField type="file" name="file" onChange={handleFileChange} />
//               <Button onClick={handleUpload}>Upload</Button>
//               {uploadStatus && (
//                 <Alert severity="success">Uploaded successfully</Alert>
//               )}
//             </Paper>
//             <Divider sx={{ backgroundColor: "#A6FF96" }} />
//             <Paper sx={{ backgroundColor: "#A6FF96", m: 3 }}>
//               <Card>
//                 <Stack direction="column" spacing={3} sx={{ m: 2 }}>
//                   <TextField
//                     label="Student Name"
//                     sx={{ m: 2 }}
//                     onChange={handleNameChange}
//                   />
//                   <TextField
//                     label="Student Subject"
//                     sx={{ m: 2 }}
//                     onChange={handleSubjectChange}
//                   />
//                   <TextField
//                     label="Student Age"
//                     sx={{ m: 2 }}
//                     onChange={handleAgeChange}
//                   />
//                   <Button onClick={null}>Save</Button>
//                   {submissionStatus && (
//                     <Alert severity="success">Student saved successfully</Alert>
//                   )}
//                 </Stack>
//               </Card>
//             </Paper>
//           </Stack>
//         </Paper>
//       </Stack>
//     </div>
//   );
// };

import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Alert,
  Button,
  Card,
  CardContent,
  Divider,
  FormLabel,
  Grid,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import ModeEditIcon from "@mui/icons-material/ModeEdit";

const Profile = () => {
  const [file, setFile] = useState(null);
  const [fileUploadStatus, setFileUploadStatus] = useState(false);
  const [studentSaveStatus, setSaveStatus] = useState(false);
  const [students, setStudents] = useState([]);

  const [enteredName, setEnteredName] = useState("");
  const [enteredSubject, setEnteredSubject] = useState("");
  const [enteredAge, setEnteredAge] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:3001/api/student");
      setStudents(response.data);
    } catch (error) {
      console.log(error.message);
    }
  };

  const handleNameChange = (event) => {
    setEnteredName(event.target.value);
  };

  const handleSubjectChange = (event) => {
    setEnteredSubject(event.target.value);
  };

  const handleAgeChange = (event) => {
    setEnteredAge(event.target.value);
  };

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleAddStudentSubmit = async (event) => {
    event.preventDefault();
    const data = {
      name: enteredName,
      age: +enteredAge,
      subject: enteredSubject,
    };
    try {
      const response = await axios.post(
        "http://localhost:3001/api/student/",
        data,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (response.status === 200) {
        setSaveStatus(true);
        fetchData();
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  const fileUploadHandler = async (event) => {
    if (!file) {
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      await axios.post("http://localhost:3001/api/student/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setFileUploadStatus(true);
      fetchData();
    } catch (error) {
      console.error("Error uploading data", error.message);
    }
  };

  const handleDeleteStudent = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/api/student/${id}`);
      fetchData();
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <Stack
      direction="row"
      style={{ marginLeft: 35, marginTop: 15 }}
      spacing={1}
    >
      <Paper elevation={6} sx={{ width: "30%", backgroundColor: "#071952" }}>
        <Stack direction={"column"}>
          <h4 style={{ color: "#35A29F" }}>Student Bulk Upload</h4>
          <Paper sx={{ backgroundColor: "#088395", m: 10 }}>
            <FormLabel>File Upload (.csv)</FormLabel>
            <TextField type="file" onChange={handleFileChange} />
            <br />
            <Button
              variant="contained"
              style={{ color: "white", marginTop: 10 }}
              onClick={fileUploadHandler}
            >
              Upload
            </Button>
            {fileUploadStatus && (
              <Alert severity="success">CSV File Upload Successfully</Alert>
            )}
          </Paper>
          <Divider sx={{ backgroundColor: "#AED2FF" }} />
          <Paper sx={{ backgroundColor: "#AED2FF", m: 3 }}>
            <Card direction="column">
              <Stack direction="column" spacing={2} sx={{ m: 3 }}>
                <Typography variant="h5">Add Student</Typography>
                <Divider />
                <TextField
                  value={enteredName}
                  onChange={handleNameChange}
                  label="Student Name"
                  sx={{ m: 3 }}
                />
                <TextField
                  value={enteredSubject}
                  onChange={handleSubjectChange}
                  label="Student Subject"
                  sx={{ m: 3 }}
                />
                <TextField
                  value={enteredAge}
                  onChange={handleAgeChange}
                  label="Age"
                  sx={{ m: 3 }}
                />
                <Button
                  onClick={handleAddStudentSubmit}
                  sx={{ m: 3 }}
                  color="success"
                  variant="contained"
                >
                  Save
                </Button>
                {studentSaveStatus && (
                  <Alert severity="success">Saved Student Successfully</Alert>
                )}
              </Stack>
            </Card>
          </Paper>
        </Stack>
      </Paper>
      <Paper
        elevation={6}
        style={{ marginRight: 15 }}
        sx={{ width: "70%", backgroundColor: "#35A29F" }}
      >
        <h1 align="center">Students</h1>
        <Grid container spacing={1} sx={{ m: 1 }}>
          {students.map((student, index) => {
            return (
              <Grid item xs={2} sm={3} md={4} key={index}>
                <Card>
                  <CardContent>
                    <Typography variant="h5" component="h5">
                      Student Name: {student.name}
                    </Typography>
                    <Typography variant="h5" component="h5">
                      Student Subject: {student.subject}
                    </Typography>
                    <Typography variant="h5" component="h5">
                      Age: {student.age}
                    </Typography>
                    <Button
                      sx={{ marginTop: 3 }}
                      variant="contained"
                      color="info"
                      startIcon={<ModeEditIcon />}
                    >
                      Update
                    </Button>
                    <Button
                      sx={{ marginTop: 3, marginLeft: 5 }}
                      variant="contained"
                      color="error"
                      startIcon={<DeleteIcon />}
                      onClick={() => handleDeleteStudent(student._id)}
                    >
                      Delete
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Paper>
    </Stack>
  );
};

export default Profile;
