import {
  Paper,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableBody,
  Table,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";

const ViewFaculty = () => {
  const [facultyList, setFacultyList] = useState([]);

  const fetchFacultyData = async () => {
    try {
      const response = await axios.get("http://localhost:3001/api/faculty");
      setFacultyList(response.data);
    } catch (error) {
      console.log("Error: ", error.message);
    }
  };

  useEffect(() => {
    fetchFacultyData();
  }, []);

  return (
    <div>
      <h2 align="center">Faculty Details</h2>
      <TableContainer component={Paper}>
        <Table>
          <TableHead style={{ backgroundColor: "magenta", fontWeight: "bold" }}>
            <TableRow>
              <TableCell>Faculty ID</TableCell>
              <TableCell>Faculty Name</TableCell>
              <TableCell>Department</TableCell>
              <TableCell>Designation</TableCell>
              <TableCell>Qualification</TableCell>
              <TableCell>Email Adress</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {facultyList.map((faculty) => {
              return (
                <TableRow key={faculty._id}>
                  <TableCell>{faculty.id}</TableCell>
                  <TableCell>{faculty.name}</TableCell>
                  <TableCell>{faculty.department}</TableCell>
                  <TableCell>{faculty.designation}</TableCell>
                  <TableCell>{faculty.qualification}</TableCell>
                  <TableCell>{faculty.email}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default ViewFaculty;
