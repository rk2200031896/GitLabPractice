import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Alert, Button, Grid, TextField } from "@mui/material";

const UpdateFaculty = () => {
  const { id } = useParams();
  const [name, setName] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [qualification, setQualification] = useState("");
  const [email, setEmail] = useState("");

  const [submissionStatus, setSubmissionStatus] = useState(false);

  const fetchFacultyData = async () => {
    try {
      const response = await axios.get(
        `http://localhost:3001/api/faculty/${id}`
      );
      const faculty = response.data;
      setName(faculty.name);
      setDepartment(faculty.department);
      setDesignation(faculty.designation);
      setQualification(faculty.qualification);
      setEmail(faculty.email);
    } catch (error) {
      console.log("Error: ", error.message);
    }
  };

  useEffect(() => {
    fetchFacultyData();
  }, []);

  const handleDesignationChange = (event) => {
    setDesignation(event.target.value);
  };

  const handleQualificationChange = (event) => {
    setQualification(event.target.value);
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const saveHandler = async (event) => {
    event.preventDefault();
    try {
      await axios.patch(`http://localhost:3001/api/faculty/${id}`, {
        designation: designation,
        qualification: qualification,
        email: email,
      });
      fetchFacultyData();
      setSubmissionStatus(true);
    } catch (error) {
      console.log("Error: ", error.message);
    }
  };

  return (
    <div>
      <h2 align="center">Update Faculty</h2>
      <div className="App">
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField label="Faculty ID" value={id} size="small" disabled />
          </Grid>
          <Grid item xs={12}>
            <TextField
              value={name}
              label="Faculty Name"
              size="small"
              disabled
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              value={department}
              label="Department"
              size="small"
              disabled
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              value={designation}
              label="Designation"
              size="small"
              onChange={handleDesignationChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              value={qualification}
              label="Qualification"
              size="small"
              onChange={handleQualificationChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              value={email}
              label="Email Address"
              size="small"
              onChange={handleEmailChange}
            />
          </Grid>
          <Grid item xs={12}>
            <Button
              variant="contained"
              color="success"
              style={{ alignContent: "right" }}
              onClick={saveHandler}
            >
              Update
            </Button>
          </Grid>
        </Grid>
        {submissionStatus && (
          <Alert
            severity="success"
            sx={{ display: "flex", justifyContent: "center" }}
          >
            Succesfully saved faculty details
          </Alert>
        )}
      </div>
    </div>
  );
};

export default UpdateFaculty;
