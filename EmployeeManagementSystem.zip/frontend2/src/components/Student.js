import React from "react";

const Student = () => {
  return (
    <div>
      <h2 align="center">Student</h2>
    </div>
  );
};

export default Student;
