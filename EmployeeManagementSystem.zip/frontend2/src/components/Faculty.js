import React from "react";
import { Link, Outlet } from "react-router-dom";

const Faculty = () => {
  return (
    <>
      <div>
        <nav style={{ textAlign: "center" }}>
          <Link to="addFaculty">Add Faculty</Link>
          <Link to="viewFaculty">View Faculty</Link>
          <Link to="updateFaculty">Update Faculty</Link>
          <Link to="deleteFaculty">Delete Faculty</Link>
        </nav>
      </div>
      <div>
        <Outlet />
      </div>
    </>
  );
};

export default Faculty;
