import {
  Paper,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableBody,
  Table,
  Button,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";

const DeleteFaculty = () => {
  const [facultyList, setFacultyList] = useState([]);

  const fetchFacultyData = async () => {
    try {
      const response = await axios.get("http://localhost:3001/api/faculty");
      setFacultyList(response.data);
    } catch (error) {
      console.log("Error: ", error.message);
    }
  };

  useEffect(() => {
    fetchFacultyData();
  }, []);

  const deleteHandler = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/api/faculty/${id}`);
      fetchFacultyData();
    } catch (error) {
      console.log("Error: ", error.message);
    }
  };

  return (
    <div>
      <h2 align="center">Faculty Details</h2>
      <TableContainer component={Paper}>
        <Table>
          <TableHead style={{ backgroundColor: "magenta", fontWeight: "bold" }}>
            <TableRow>
              <TableCell>Faculty ID</TableCell>
              <TableCell>Faculty Name</TableCell>
              <TableCell>Department</TableCell>
              <TableCell>Designation</TableCell>
              <TableCell>Qualification</TableCell>
              <TableCell>Email Adress</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {facultyList.map((faculty) => {
              return (
                <TableRow key={faculty._id}>
                  <TableCell>{faculty.id}</TableCell>
                  <TableCell>{faculty.name}</TableCell>
                  <TableCell>{faculty.department}</TableCell>
                  <TableCell>{faculty.designation}</TableCell>
                  <TableCell>{faculty.qualification}</TableCell>
                  <TableCell>{faculty.email}</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      color="error"
                      onClick={() => {
                        deleteHandler(faculty.id);
                      }}
                    >
                      Delete
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default DeleteFaculty;
